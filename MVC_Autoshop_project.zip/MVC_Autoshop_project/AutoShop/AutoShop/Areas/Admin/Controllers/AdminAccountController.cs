﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Helpers;
using System.Web.Mvc;
using AutoShop.Models;

namespace AutoShop.Areas.Admin.Controllers
{
    public class AdminAccountController : Controller
    {

        private readonly AutoShopDBEntities db;

        public AdminAccountController()
        {
            db = new AutoShopDBEntities();
        }


        // GET: Admin/AdminAccount
        public ActionResult Login()
        {
            return View();
        }


        [HttpPost]
        public ActionResult Login(string username, string password)
        {
            User user = db.Users.FirstOrDefault(u => u.Username == username);


            if (user != null && Crypto.VerifyHashedPassword(user.Password, password) && user.IsAdmin == true)
            {
                Session["user"] = user;
                return RedirectToAction("Index", "Dashboard");
            };

            ViewBag.LoginError = "Username or password is wrong.";

            return View();
        }
    }
}