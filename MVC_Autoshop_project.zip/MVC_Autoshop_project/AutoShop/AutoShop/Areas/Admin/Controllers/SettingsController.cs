﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AutoShop.Models;

namespace AutoShop.Areas.Admin.Controllers
{
    public class SettingsController : Controller
    {

        private readonly AutoShopDBEntities db;

        public SettingsController()
        {
            db = new AutoShopDBEntities();
        }


        // GET: Admin/Settings
        public ActionResult Index()
        {

            return View(db.News.OrderByDescending(n=> n.NewsDate));
        }
 
        // GET: Admin/Settings/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Admin/Settings/Create
        [HttpPost]
        public ActionResult Create([Bind(Exclude = "Image")]News news, HttpPostedFileBase Image)
        {

            if (ModelState.IsValid)
            {
                if (Extensions.CheckImageType(Image))
                {
                    news.Image = Extensions.SaveImage(Server.MapPath("~/Public/img/car"), Image);
                    news.NewsDate = DateTime.Now;
   
                    News addedNews = null;

                    addedNews = db.News.Add(news);
                    db.SaveChanges();

                    return RedirectToAction("Index", "Settings");

                }
            }
            return View();
        }

        // GET: Admin/Settings/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
                return HttpNotFound("ID is missing");

            News news = db.News.Find(id);

            if (news == null)
                return HttpNotFound("ID was not found");

            return View(news);
        }

        // POST: Admin/Settings/Edit/5
        [HttpPost]
        public ActionResult Edit([Bind(Exclude = "Image")]News news, HttpPostedFileBase Image)
        {
            if (ModelState.IsValid)
            {
                if (Extensions.CheckImageType(Image))
                {
                    news.Image = Extensions.SaveImage(Server.MapPath("~/Public/img/car"), Image);
                    news.NewsDate = DateTime.Now;

                    News addedNews = null;

                    addedNews = db.News.Add(news);
                    db.SaveChanges();

                    return RedirectToAction("Index", "Settings");

                }
            }
            return View();
        }

        // GET: Admin/Settings/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
                return HttpNotFound("ID is missing");

            News news = db.News.Find(id);

            if (news == null)
                return HttpNotFound("ID was not found");

            return View(news);
        }

        // POST: Admin/Settings/Delete/5
        [HttpPost]
        [ActionName("Delete")]
        public ActionResult DeleteConfirm(int id)
        {
           News news = db.News.Find(id);
            db.News.Remove(news);
            db.SaveChanges();

            return RedirectToAction("Index");
        }
    }
}
