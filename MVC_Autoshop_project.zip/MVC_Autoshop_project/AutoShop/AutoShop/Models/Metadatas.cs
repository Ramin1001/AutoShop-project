﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace AutoShop.Models
{
    [MetadataType(typeof(UserMetadata))]
    public partial class User
    {

        public string Fullname
        {
            get
            {
                return Firstname + " " + Lastname;
            }
        }

        private class UserMetadata
        {

            //public int ID { get; set; }

            [Required(ErrorMessage ="This field is Required", AllowEmptyStrings = false)]
            public string Firstname { get; set; }
            [Required(ErrorMessage = "This field is Required", AllowEmptyStrings = false)]
            public string Lastname { get; set; }

            [Required(ErrorMessage = "This field is Required", AllowEmptyStrings = false)]
            [DataType(DataType.EmailAddress)]
            [EmailAddress]
            public string Email { get; set; }

            [Required(ErrorMessage ="You have to write password.", AllowEmptyStrings =false)]
            [DataType(System.ComponentModel.DataAnnotations.DataType.Password)]
            [StringLength(255, MinimumLength =6, ErrorMessage ="Password must be 6 char minimum.")]
            public string Password { get; set; }
        }

    }

    [MetadataType(typeof(ModelMetadata))]
    public partial class Model
    {
        private class ModelMetadata
        {
            [Required, MinLength(3), MaxLength(100)]
            public string Name { get; set; }
            public Nullable<int> CreateYear { get; set; }
            public string MotorCub { get; set; }
            public Nullable<decimal> Price { get; set; }
            public int MarkalD { get; set; }
            public string Transmission { get; set; }
            public string Color { get; set; }

            [Required, MinLength(50), MaxLength(200)]
            public string Description { get; set; }
            public Nullable<System.DateTime> PostCreated { get; set; }
            public Nullable<System.DateTime> PostUpdated { get; set; }
            public string WherePosted { get; set; }
            public string TypeOfFuel { get; set; }
            public string Image { get; set; }
            public Nullable<bool> IsVIP { get; set; }
            public string Mileage { get; set; }
            public Nullable<int> UserID { get; set; }
        }

    }


    public partial class News
    {
        private class NewsMetadata
        {
            [Required, MinLength(5), MaxLength(150)]
            public string Title { get; set; }

            [Required, MinLength(100)]
            public string Content { get; set; }
            public string Image { get; set; }
            public Nullable<System.DateTime> NewsDate { get; set; }
        }
    }

}