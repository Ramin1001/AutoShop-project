﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AutoShop.Models;


namespace AutoShop.ViewModels
{
    public class ForHomePage
    {
        public IEnumerable<Slider> Sliders { get; set; }
        public IEnumerable<Model> Models { get; set; }
        public IEnumerable<Marka> Markas { get; set; }
        public IEnumerable<News> News { get; set; }
    }
}