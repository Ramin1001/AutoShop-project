﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AutoShop.Models;

namespace AutoShop.ViewModels
{
    public class PersonalPageVM
    {
        public User User { get; set; }
        public IEnumerable<Model> ModelsVIP { get; set; }
        public IEnumerable<Model> Models { get; set; }
        public IEnumerable<Marka> Markas { get; set; }
        public IEnumerable<Model> UserModel { get; set; }
    }
}