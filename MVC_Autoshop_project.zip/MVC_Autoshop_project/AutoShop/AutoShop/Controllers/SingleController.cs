﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AutoShop.Models;
using AutoShop.ViewModels;

namespace AutoShop.Controllers
{
    public class SingleController : Controller
    {
        private readonly AutoShopDBEntities db;

        public SingleController()
        {
            db = new AutoShopDBEntities();
        }


        // GET: Single
        public ActionResult AutoDetails(int? id)
        {
            if (id == null)
                return HttpNotFound();

            Model model = db.Models.Find(id);

            if (model == null)
                return HttpNotFound("Car not found.");

            SingleVM singleModel = new SingleVM
            {
                Model = model,
                ModelImages=db.ModelImages.Where(mi=> mi.ModelID==model.ID),
                Models=db.Models.Where(m=> m.MarkalD == model.MarkalD),
                News = db.News.OrderByDescending(p => p.NewsDate).Take(5)
            };


            return View(singleModel);
        }


        public ActionResult NewsSingle(int? id)
        {
            if (id == null)
                return HttpNotFound();

            News news = db.News.Find(id);

            if (news == null)
                return HttpNotFound("News was not found.");

            NewsVM newsVM = new NewsVM
            {
                News=news,
                Newses=db.News.OrderByDescending(o=> o.NewsDate).Take(5)
            };

            return View(newsVM);
        }





    }
}