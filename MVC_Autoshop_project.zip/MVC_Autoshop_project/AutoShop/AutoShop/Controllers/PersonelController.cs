﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using AutoShop.Models;
using AutoShop.ViewModels;

namespace AutoShop.Controllers
{
    [AutorizeUserFilter]
    public class PersonelController : Controller
    {

        private readonly AutoShopDBEntities db;

        public PersonelController()
        {
            db = new AutoShopDBEntities();
        }


        // GET: Personel
        public ActionResult PersonelPage()
        {
            int userId = (Session["user"] as User).ID;

            PersonalPageVM pageVM = new PersonalPageVM
            {
                ModelsVIP = db.Models.OrderByDescending(v => v.IsVIP == true),
                Models = db.Models.OrderByDescending(v => v.IsVIP == false),
                Markas = db.Markas,
                UserModel = db.Models.OrderByDescending(u => u.UserID == userId),
                User=(Session["user"] as User)
            };

            return View(pageVM);
        }

        public ActionResult UserProfile()
        {
            int userId = (Session["user"] as User).ID;

            var userModel = db.Models.Where(u => u.UserID == userId);

            return View(userModel);
        }




        // GET: Personel/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: Personel/Create
        public ActionResult Create()
        {
            ViewBag.Markas = new SelectList(db.Markas, "ID", "Name");
           
            return View();
        }

        // POST: Personel/Create
        [HttpPost]
        public ActionResult Create([Bind(Exclude = "Image")]Model model, HttpPostedFileBase Image, IEnumerable<int> Marka)
        {

            if (ModelState.IsValid)
            {
                if (Extensions.CheckImageType(Image))
                {
                    model.Image = Extensions.SaveImage(Server.MapPath("~/Public/img/car"), Image);
                    model.PostCreated = model.PostUpdated = DateTime.Now;
                    model.UserID = ((User)Session["user"]).ID;

                    Model addedModel = null;

                        addedModel = db.Models.Add(model);
                        db.SaveChanges();

                    return RedirectToAction("UserProfile", "Personel");

                }
            }

            ViewBag.Markas = new SelectList(db.Markas, "ID", "Name");
            return View();   
        }

        // GET: Personel/Edit/5
        public ActionResult Edit(int id)
        {



            return View();
        }

        // POST: Personel/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Personel/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
                return HttpNotFound("ID was not specified.");

            Model model = db.Models.Find(id);

            if (model == null)
                return HttpNotFound("ID is not correct.");
            return View(model);
        }

        // POST: Personel/Delete/5
        [HttpPost]
        [ActionName("Delete")]
        public ActionResult DeleteConfirm(int id)
        {
            Model model = db.Models.Find(id);
            db.Models.Remove(model);
            db.SaveChanges();

            return RedirectToAction("UserProfile");
        }


        public ActionResult Marka(String marka)
        {

            ViewBag.Markas = marka;

            return View(db.Models.Where(m=> m.Marka.Name==marka).Select(m=> m.Name));
        }


    }
}
