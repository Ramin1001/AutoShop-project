﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AutoShop.Models;
using AutoShop.ViewModels;

namespace AutoShop.Controllers
{
    
    public class HomeController : Controller
    {

        private readonly AutoShopDBEntities db;

        public HomeController()
        {
            db = new AutoShopDBEntities();
        }

        public ActionResult Index()
        {
            ForHomePage homePage = new ForHomePage
            {
                Sliders = db.Sliders,
                Models = db.Models.OrderByDescending(p => p.PostUpdated),
                Markas = db.Markas,
                News = db.News.OrderByDescending(p => p.NewsDate).Take(5)
            };
            return View(homePage);
        }



        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}