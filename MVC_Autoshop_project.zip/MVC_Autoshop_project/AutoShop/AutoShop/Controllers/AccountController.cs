﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.ServiceModel.Description;
using System.Web;
using System.Net.Http;
using System.Web.Helpers;
using System.Web.Mvc;
using AutoShop.Models;

namespace AutoShop.Controllers
{
    public class AccountController : Controller
    {
        private readonly AutoShopDBEntities db;

        public AccountController()
        {
            db = new AutoShopDBEntities();
        }


        // GET: Account
        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(string username, string password)
        {
            User user = db.Users.FirstOrDefault(u => u.Username == username);
           

            if (user !=null && Crypto.VerifyHashedPassword(user.Password, password))
            {
                Session["user"] = user;
                return RedirectToAction("PersonelPage", "Personel");
            };

            ViewBag.LoginError = "Username or password is wrong.";

            return View();
        }



        public ActionResult Logout()
        {
            Session.Clear();
            return RedirectToAction("Index","Home");
        }

       


     
        public ActionResult Register()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Register(User user)
        {
  
            var errors = ModelState.Values.SelectMany(v => v.Errors);
            if (ModelState.IsValid)
            {
               

                if ((db.Users.FirstOrDefault(u=> u.Username==user.Username))!=null)
                {
                    ModelState.AddModelError("Username","This username alredy exist. Enter another username");
                    return View();
                }

                if ((db.Users.FirstOrDefault(u => u.Email == user.Email)) != null)
                {
                    ModelState.AddModelError("Email","This email alredy exist. Enter another email");
                    return View();
                }

                User newUser = new User
                {
                    Firstname=user.Firstname,
                    Lastname = user.Lastname,
                    Username=user.Username,
                    Email=user.Email,
                    Password=(Crypto.HashPassword(user.Password))
                };


                db.Users.Add(newUser);
                db.SaveChanges();
                ModelState.Clear();
                user = null;
                ViewBag.Messages = "Registration is done successfully";
            }

            return View();
        }
    }
}